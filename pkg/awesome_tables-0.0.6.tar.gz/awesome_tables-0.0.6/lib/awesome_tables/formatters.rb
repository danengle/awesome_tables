=begin
require 'awesome_tables/formatters/html'

module AwesomeTables
  class Formatter
    class << self
      def output(type, awesome_table)
        case type
      end
    end
  end
end
=end