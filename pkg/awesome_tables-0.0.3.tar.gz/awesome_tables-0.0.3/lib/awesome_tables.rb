module AwesomeTables
end

if defined?(::Rails::Railtie)
  require 'awesome_tables/railtie'
end