=begin
require 'awesome_tables/formatters'

module AwesomeTables
  module Formatters
    class Html < Formatter
      def self.output
    end
  end
end
=end