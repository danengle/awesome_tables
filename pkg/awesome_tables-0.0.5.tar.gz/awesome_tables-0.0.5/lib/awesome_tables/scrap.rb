def test(*args)
  puts "1. #{args}"
end